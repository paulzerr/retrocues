close all; 
clear all;

addpath(genpath([pwd '\helpers\']));

windowsizes = [1 5:5:60 60:20:300 350:50:500];

% only make reported graph
windowsizes = 200;

totaltrials     = 1587;
sequence        = 1:1587;
hres_sequence   = min(sequence):.01:max(sequence);


recompute = 1;


% plot space to axes
spaceleft       = 10;
spaceright      = 10;
% cover that space with whiteness?
plotwhitespace  = 0;

% thickness of lines in panel B
fitthick        = 2;
rawthick        = 2;

% colors
rcol            = [0 .35 .6];
pcol            = [.7 .2 .1];
hdialpha        = 0.3;

% fit colors
lincol          = [0.596078431372549         0.266666666666667         0.392156862745098];
expcol          = [0.235294117647059         0.682352941176471          0.63921568627451];
sigcol          = [0         0.403921568627451         0.541176470588235];

% d and bf colors
deltacol        = [0 0 0];%[0.235294117647059         0.682352941176471          0.63921568627451];
bfcol           = [0 .2 .2];%deltacol - .2;

transparency    = .3;
legendfontsize  = 12; 

% load raw data
load('binary_response_data')



for windowsizeindex = 1:length(windowsizes)
    
    close all
    
    f1 = figure(1);
    %clf(f1)
    f1.WindowState = 'maximized';
    
    set(gcf,'color','white')
    set(gcf,'defaultAxesColorOrder',[0 0 0; 0 0 0]);
    
    if recompute 
    
        windowsize = windowsizes(windowsizeindex);

        load(['mu_2to600_' num2str(windowsize)])
        load(['ds_2to600_' num2str(windowsize)])
        windowsizes = [1 5:5:60 60:20:300 350:50:500];

        sigma1s = sigma1s ./sqrt(10);
        sigma2s = sigma2s ./sqrt(10);
        rb=mu2s'-mu1s';   

        all1smooth=movmean(all1,[windowsize/2 windowsize/2]);
        all2smooth=movmean(all2,[windowsize/2 windowsize/2]);
        
        
        %%% LINEAR MODEL
        try
            modelfun_lin = @(b,x) b(1).*x + b(2);
            mdl_lin = fitnlm(sequence',rb,modelfun_lin,[0 0.1])    
            linfit_vals = feval(mdl_lin, hres_sequence); 
            lingoodnessoffit=mdl_lin.ModelCriterion.BIC;
        catch
            lingoodnessoffit=nan;
            linfit_vals = nan(1,length(hres_sequence));
        end


        %%% EXPONENTIAL MODEL
        try
            modelfun_exp = @(b,x) b(1) .* exp(b(2)*x) + b(3);
            mdl_exp = fitnlm(sequence',rb,modelfun_exp,[-.1 -.01 0])
            expfit_vals = feval(mdl_exp,hres_sequence); 
            expgoodnessoffit=mdl_exp.ModelCriterion.BIC;
        catch
            expgoodnessoffit=nan;
            expfit_vals = nan(1,length(hres_sequence));
        end


        %%% LOGISTIC MODEL
        try
            modelfun_sig = @(b,x) b(1) + (b(2) - b(1)) ./  (1+(x/b(3)).^b(4));
            mdl_sig = fitnlm(sequence',rb,modelfun_sig,[0.1 0.1 200 5]);
            sigfit_vals = feval(mdl_sig,hres_sequence);
            siggoodnessoffit=mdl_sig.ModelCriterion.BIC;
        catch
            sigfitgoodness=nan;
            sigfit_vals = nan(1,length(sequence));
        end
    
        save('fit_vals');
     
    else 
        load('fit_vals')
    end
    
    


    ax = gca;
    cm = colormap(ax,flipud(viridis(size(mu1s,1))));


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% PLOT 111: Accuracies
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    subplot(3,1,1)
    hold on

    ax = gca;
    cm = colormap(ax,flipud(viridis(size(mu1s,1))));

    p1=plot(sequence,mu1s','-','color',pcol,'linewidth',2);
    p2=plot(sequence,mu2s','-','color',rcol,'linewidth',2);


    hc1 = ciplot(mu1s'-sigma1s',mu1s'+sigma1s',sequence); 
    set(hc1,'facealpha',hdialpha,'facecolor',pcol,'edgealpha',0);
    hc2 = ciplot(mu2s'-sigma2s',mu2s'+sigma2s',sequence); 
    set(hc2,'facealpha',hdialpha,'facecolor',rcol,'edgealpha',0);


    i1=plot(all1smooth,'-','color',pcol);
    i2=plot(all2smooth,'-','color',rcol);
    transparency=0.4;
    for i=1:10
        i1(i).Color(4) = transparency;
        i2(i).Color(4) = transparency;
    end



    text(-0.07,1.05,'A','Units','normalized','fontsize',21,'fontweight','bold')

    set(gca,'fontsize',15);   
    ax = gca;
    ax.LineWidth    = 1;
    ax.XGrid        = 'on';
    ax.YGrid        = 'on';
    ax.XAxis.Visible = 'off';
    ax.TickLength = [0.0075 0.0075];
    ax.TickDir      = 'out';


    legendplot1=plot(-100,0,'-','linewidth',2,'color',pcol);
    legendplot2=plot(-100,0,'-','linewidth',2,'color',rcol);

    l1 = legend([legendplot2 legendplot1],{' retro',' post'},'location','northwest');
    l1.FontSize = legendfontsize;
    l1.Position = [0.139090871584512 0.877650561886848 0.0534179694298655 0.0409977072969488];
    l1.FontName = 'FixedWidth';

    title(['moving average window size ' num2str(windowsize)])

    set(legend,'EdgeColor','none');
    ylabel('accuracy (%)')

    xticks([1:100:totaltrials]);
    xticklabels([]);
    yticks(.5:.1:.9)
    yticklabels(50:10:90) 

    axis([-spaceleft totaltrials+spaceright .5 .9])


    if plotwhitespace

        pos = [-spaceleft+2 .45 spaceleft+1 .47];
        r3 = rectangle('Position',pos,'facecolor',[1 1 1],'edgecolor',[1 1 1]);

    end



    yyaxis right
    axis([-spaceleft totaltrials+spaceright .5 .9])
    ylabel("Cowan's k")


    makek = @(acc) (acc*2-1)*12;
    vector = [0.5:0.0000001:.9];
    m1 = makek(vector);

    allyticks=[];
    allyticklabels=[];

    for i=0:9
        ix = get_ix( m1,i);

        allyticks = [allyticks vector(ix)];
        allyticklabels = [allyticklabels i];
    end

    yticks(allyticks([1 3 5 7 9]))
    yticklabels(allyticklabels([1 3 5 7 9]))



    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% PLOT 222: RC Benefit
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    subplot(3,1,2)
    hold on

    % raw data
    p0=plot(sequence,rb,'-','color',[0 0 0],'linewidth',rawthick);
    p0.Color(4) = 1;

    % fits
    p1 = plot(hres_sequence,linfit_vals,':','linewidth',fitthick+1,'color',lincol);
    p2 = plot(hres_sequence,expfit_vals,'--','linewidth',fitthick+1,'color',expcol);
    p3 = plot(hres_sequence,sigfit_vals,'-','linewidth',fitthick+1,'color',sigcol);


    xticks([1:100:totaltrials])
    xticklabels([])
    yticks([-.06:0.02:.14])
    yticklabels([-6:2:14])


    if windowsize<200
        min_y = -.06;
        max_y = .14;
    else
        min_y =   0;
        max_y = .12;        
    end
    
    
    axis([-spaceleft totaltrials+spaceright min_y max_y ])
    %axis([-spaceleft totaltrials+spaceright -.00 .12 ])


    ax = gca;
    ax.LineWidth    = 1;
    ax.XGrid        = 'on';
    ax.YGrid        = 'on';
    ax.FontSize     = 15;
    ax.XAxis.Visible = 'off';
    ax.TickLength = [0.0075 0.0075];
    ax.TickDir      = 'out';
    ax.Clipping = 'on';


    ylabel('retro-cue benefit (%)')


    if plotwhitespace
        pos = [-spaceleft+2 -.01 spaceleft+1 .15];
        r3 = rectangle('Position',pos,'facecolor',[1 1 1],'edgecolor',[1 1 1]);
    end


    linlegend=[' linear      (- ' num2str(round(abs(lingoodnessoffit))) ')   '];
    explegend=[' exponential (- ' num2str(round(abs(expgoodnessoffit))) ')   '];
    siglegend=[' logistic    (- ' num2str(round(abs(siggoodnessoffit))) ')   '];

    l2 = legend([p0 p1 p2 p3],{' retro-post', linlegend, explegend, siglegend});
    set(legend,'EdgeColor','none','location','northwest');
    l2.Position = [0.742269442007256 0.414721880802812 0.137792971441522 0.0786506133706554]
    %l2.Position = [0.138363192174894 0.543162247775289 0.123730471106246 0.0786506133706563];

    l2.FontSize = legendfontsize;
    l2.FontName = 'FixedWidth';

    text(-0.07,1.05,'B','Units','normalized','fontsize',21,'fontweight','bold')

% 
%     
%     
    yyaxis right
    
    
    makek = @(acc) (acc*2-1)*12;
    
    vector = [0:0.0000001:1];
    m1 = makek(vector);

    allyticks=[];
    allyticklabels=[];

    for i = -1:3
        ix = get_ix( m1,i);
        allyticks = [allyticks vector(ix)-.5];
        allyticklabels = [allyticklabels i];
    end

    yticks(allyticks)
    yticklabels(allyticklabels)
    
    
    
    axis([-spaceleft totaltrials+spaceright min_y max_y ])
    ylabel("{\Delta} k")



    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% PLOT 333: Bayes Factors
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    subplot(3,1,3)
    hold on

    p1=plot(sequence,-deltas,'-','linewidth',1.5,'color',deltacol);

    ax = gca;
    ax.ColorOrder   = cm;
    ax.LineWidth    = 1;
    ax.FontSize     = 15;
    ax.XGrid        = 'on';
    ax.YGrid        = 'on';
    ax.YMinorGrid   = 'off';
    ax.TickDir      = 'out';
    ax.TickLength = [0.0075 0.0075];



    culurmap=flipud(lines(length(windowsizes)+1));
    culurmap(1,:)=[];
    culurmap = culurmap([2 3 4 1],:);
    cm = colormap(ax,culurmap);

    if plotwhitespace
        pos = [1588 -0.1 40 1500];
        r1 = rectangle('Position',pos,'facecolor',[1 1 1],'edgecolor',[1 1 1]);
        uistack(r1,'top')
    end

    text(-0.07,1.05,'C','Units','normalized','fontsize',21,'fontweight','bold')

    xlabel('trial time')
    ylabel('effect size (d)')

    xticks([1 100:100:totaltrials]);
    xticklabels([1 100:100:totaltrials]);
    yticks([0:.5:3])
    axis([-spaceleft totaltrials+spaceright 0 3])


    yyaxis right

    ax = gca;
    ax.ColorOrder   = cm;
    ax.LineWidth    = 1;
    ax.FontSize     = 15;
    ax.XGrid        = 'on';
    ax.YScale       = 'log';
    ax.YMinorGrid   = 'off';
    ax.TickDir      = 'out';
    ax.TickLength = [0.0075 0.0075];

    plot([-length(bfs)/15 length(bfs)+length(bfs)/15],[1 1],'-k','linewidth',.5 )
    plot([-length(bfs)/15 length(bfs)+length(bfs)/15],[3 3],'--k','linewidth',.5  )

    ylim([0 8000])
    yt=[1 3 10 100 1000 10000 100000];
    yticks(yt) 
    %yticklabels({'1' '10^1' '10^2' '10^3' '10^4' '10^5'})
    yticklabels({'1' '3' '10' '100' '1000' '10000' '1000000'})
    p2=plot(sequence,1./bfs,':','linewidth',1.5,'color',bfcol);


    l3 = legend([p1 p2],{' d',' BF_{(d>0)}'},'location','northwest', 'Interpreter', 'tex');
    l3.FontSize = legendfontsize;
    l3.Position = [0.139191317864073 0.277202768026634 0.0659179697278887 0.0463493893817295];
    l3.FontName = 'FixedWidth';

    set(l3,'EdgeColor','none');
    ylabel('BF_{(d>0)}', 'Interpreter', 'tex')

    ax.YAxis(1).Color = 'k';
    ax.YAxis(2).Color = 'k';


    fname = [pwd '\make_gif\graphs\FIGURE3_WINDOW_' num2str(windowsize) '.png'];
    print(gcf,[fname],'-dpng','-r300');
end




function ix = get_ix( t_list,t_point)
    
    [~,ix] = min(abs(t_list-t_point));

%     if isnan(t_point) || (ix==1 && t_point<t_list(1)) ||  (ix==length(t_list) && t_point>t_list(end))
%       ix=nan; 
%     end    
%     
end
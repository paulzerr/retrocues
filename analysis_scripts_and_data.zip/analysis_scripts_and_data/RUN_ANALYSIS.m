close all
clear all
mydir  = pwd;
idcs   = strfind(mydir,'\');
newdir = mydir(1:idcs(end)-1); 
addpath(genpath([newdir '\toolbox\']));

% run the mean+sd estimation
estimate_mu  = 1;

% run effect size estimation
estimate_d   = 1;

% the trial time points to analyze
sequence = 1:1587;

windowsizes = [1 5:5:60 60:20:300 350:50:500];
% uncomment this line to analyze only for window size 200
windowsizes = [200];

% set up collector variables
deltas   = nan(1,length(sequence));
mus      = nan(1,length(sequence));
mu1sd    = nan(1,length(sequence));
mu2sd    = nan(1,length(sequence));
sigma1sd = nan(1,length(sequence));
sigma2sd = nan(1,length(sequence));
sigmas   = nan(1,length(sequence));
bfs      = nan(1,length(sequence));          
mu1s     = nan(1,length(sequence));
mu2s     = nan(1,length(sequence));
sigma1s  = nan(1,length(sequence));
sigma2s  = nan(1,length(sequence));

% load raw data
load('binary_response_data')


for w=1:length(windowsizes)

    tic
    
    windowsize = windowsizes(w)
    
    all1smooth = movmean(all1,[round(windowsize/2) round(windowsize/2)]);
    all2smooth = movmean(all2,[round(windowsize/2) round(windowsize/2)]);

    % ESTIMATE TWO MEANS AND SD'S
    if estimate_mu
        
        clear S
        clear init0
        
        counter = 0;
        for iii=sequence

            counter = counter + 1;
            fprintf('%i  \b',iii)
            if mod(iii,30)==0
                fprintf('\n')
            end

            %% Data
            x1 = all1smooth(iii,:);
            x2 = all2smooth(iii,:);
            
            % Constants
            n1 = length(x1);
            n2 = length(x2);

            %% Sampling
            % MCMC Parameters
            nchains    = 2;     % How Many Chains?
            nburnin    = 1000;  % How Many Burn-in Samples?
            nsamples   = 5000;  % How Many Recorded Samples?
            nthin      = 1;     % How Often is a Sample Recorded?
            doparallel = 1;     % Parallel Option

            % Assign Matlab Variables to the Observed WinBUGS Nodes
            datastruct = struct('x1',x1,'n1',n1,'x2',x2,'n2',n2);

            % Initialize Unobserved Variables
            for i=1:nchains
                S.mu1    = randn;
                S.mu2    = randn;
                S.sigma1 = rand;                
                S.sigma2 = rand;                
                init0(i) = S;
            end

            [samples, stats] = matjags( ...
                        datastruct, ...
                        fullfile(pwd, 'jags_model_mu.txt'), ...
                        init0, ...
                        'doparallel' , doparallel, ...
                        'nchains', nchains,...
                        'nburnin', nburnin,...
                        'nsamples', nsamples, ...
                        'thin', nthin, ...
                        'monitorparams',  {'mu1','mu2','sigma1','sigma2'}, ...
                        'savejagsoutput' , 1 , ...
                        'verbosity' , 0 , ...
                        'cleanup' , 0 , ...
                        'workingdir' , 'tmpjags' );

            mu1    = mean(reshape(samples.mu1,1,[]));
            mu2    = mean(reshape(samples.mu2,1,[]));
            sigma1 = mean(reshape(samples.sigma1,1,[]));
            sigma2 = mean(reshape(samples.sigma2,1,[]));
            
            mu1s(counter)    = mu1;
            mu2s(counter)    = mu2;
            sigma1s(counter) = sigma1;
            sigma2s(counter) = sigma2;    
            
        end
    end       
    
    
    % ESTIMATE EFFECT SIZE 
    if estimate_d
        
        clear S
        clear init0
        
        counter = 0;
        for iii=sequence

            counter = counter + 1;
            fprintf('%i  \b',iii)
            if mod(iii,30)==0
                fprintf('\n')
            end
            
            x1 = all1smooth(iii,:);
            x2 = all2smooth(iii,:);
            
            % Constants
            n1 = length(x1);
            n2 = length(x2);

            % Rescale
            x2 = x2-mean(x1);
            x2 = x2/std(x1);
            x1 = (x1-mean(x1))/std(x1); 

            %% Sampling
            % MCMC Parameters
            nchains    = 2;      % How Many Chains?
            nburnin    = 1000;   % How Many Burn-in Samples?
            nsamples   = 5000;   % How Many Recorded Samples?
            nthin      = 1;      % How Often is a Sample Recorded?
            doparallel = 1;      % Parallel Option

            % Assign Matlab Variables to the Observed WinBUGS Nodes
            datastruct = struct('x1',x1,'n1',n1,'x2',x2,'n2',n2);

            clear S
            clear init0
            
            % Initialize Unobserved Variables
            for i=1:nchains
                S.delta      = randn;
                S.mu         = randn;
                S.sigmatmp1d = rand;
                S.sigmatmp2d = rand;
                init0(i)     = S;
            end

            [samples, stats] = matjags( ...
                        datastruct, ...
                        fullfile(pwd, 'jags_model_delta.txt'), ...
                        init0, ...
                        'doparallel' , doparallel, ...
                        'nchains', nchains,...
                        'nburnin', nburnin,...
                        'nsamples', nsamples, ...
                        'thin', nthin, ...
                        'monitorparams',  {'delta','deltaprior','mu','mu1d','mu2d','sigma','sigma1d','sigma2d'}, ...
                        'savejagsoutput' , 1 , ...
                        'verbosity' , 0 , ...
                        'cleanup' , 0 , ...
                        'workingdir' , 'tmpjags' );

            crit = 0;
            eps =.02;binsc = [-3+eps/2:eps:3-eps/2];binse = [-3:eps:3];
            [f,xi] = ksdensity(reshape(samples.delta,1,[]),'kernel','normal');
            [valk indk] = min(abs(xi-crit));
            tmp = reshape(samples.deltaprior,1,[]);
            tmp = tmp(find(tmp>binse(1)&tmp<binse(end)));
            [f2,xi] = ksdensity(tmp,'kernel','normal');
            [valk2 indk2] = min(abs(xi-crit));
            v1 = f(indk); v2 = f2(indk2);
            bf = [v1/v2];
            
            delta  = mean(reshape(samples.delta,1,[]));
            mu     = mean(reshape(samples.mu,1,[]));
            mu1d   = mean(reshape(samples.mu1d,1,[]));
            mu2d   = mean(reshape(samples.mu2d,1,[]));
            sigma  = mean(reshape(samples.sigma,1,[]));
            sigma1d = mean(reshape(samples.sigma1d,1,[]));
            sigma2d = mean(reshape(samples.sigma2d,1,[]));
            
            deltas(counter)   = delta;
            mus(counter)      = mu;
            mu1sd(counter)    = mu1d;
            mu2sd(counter)    = mu2d;
            sigmas(counter)   = sigma;            
            sigma1sd(counter) = sigma1d;
            sigma2sd(counter) = sigma2d;     
            bfs(counter)      = bf;

            
        end
    end        
        
    
    if estimate_mu
        save(['mu_2to600_' num2str(windowsize)],'sequence','windowsizes','mu1s','mu2s','sigma1s','sigma2s')
    end

    if estimate_d
        save(['ds_2to600_' num2str(windowsize)],'sequence','windowsizes','deltas','mus','mu1sd','mu2sd','sigmas','bfs','sigma1sd','sigma2sd')
    end    

    toc
end


Note that the character here doesn't evolve. To make this work replace Bird1.png - Bird8.png with different images. We have removed the stimuli used in the experiment to avoid any potential copyright issues when releasing the code.

The current evolving character was sourced from:

Challener, S. (Redshrike). [Online image]. Open Game Art. https://opengameart.org/content/more-rpg-enemies
function [p] = SETTINGS(environment)


p.dummymode        = 1;  % no eyetracker?
p.dopracticeround  = 0;  % practice blocks?
p.isolum           = 0;  % isoluminance measure?
p.getsubjinfo      = 0;  % record subject info?
p.check_gaze       = 0;  % do we control gaze point?
p.soundfeedback    = 0;  % play sound feedback?
p.choosecharacter  = 0;  % 0 = chicken as default character
p.showinstructions = 0;  % show task instructions

p.synctest         = 0;  % to enable secure experimental mode: this should always be 1 during experiment sessions!
p.debug            = 0;  % 1 = display trial type and go quickly; 2 = display trial type and go slow
p.takescreenshot   = 0;  % save screen images?
p.fliptester       = 0;  % to check frame timings

p.blocks                = Inf; % experiment blocks
p.cycles                = 16;  % multiplier for trials per block
p.feedbackeveryxtrials  = 100;  % feedback graph after how many trials?
p.isoluminance_trials   = 10;  % trials per luminance calibration
p.breakafterxtrials     = 64; % how long until break?

p.level                 = 1;
p.min_trials_to_evolve  = 60;
p.character             = 1;

p.charactername         = 'Bird';

%-------------------------------------------------------------------------%
%% SCREEN
p.scrnum       = max(Screen('Screens'));
p.scr          = Screen('Resolution',p.scrnum);
p.scr.ifi      = 1/p.scr.hz; 
p.xCenter      = p.scr.width/2;
p.yCenter      = p.scr.height/2;
p.flips        = [];

%%% pixels per degree
screen_px = p.scr.height;%p.scr.width
if strcmp(environment,'home')
    distance_from_screen = 65;    
    screen_cm = 31.63;%55.25;

elseif strcmp(environment,'lab')
    distance_from_screen = 65;
    screen_cm = 34;%55.25;
end
visual_angle = 2 * atand(.5*screen_cm/distance_from_screen);
p.pixels_per_degree = screen_px/(visual_angle);
%-------------------------------------------------------------------------%






%-------------------------------------------------------------------------%
%% NOISE TEXTURE SETTINGS
p.totalnoisetex  = 32; % noise patches to create
p.noiseluminance = 75; % maximum noise luminance (1-255)
p.noisestartsize = 1;  % smallest noise pixel size
p.noiseendsize   = 10; % largest noise pixel size
p.framestorun    = 6;  % how many frames do we want to display
p.noiseangle     = 50; % gaussian noise angle: 1 - exp(-((x/angle).^2)-((y/angle).^2));
p.scale          = 5;  % scaling of noise pixels
p.kwidth         = 3;  % kernel width
%-------------------------------------------------------------------------%



%-------------------------------------------------------------------------%
 
p.spacecue              = 1;


% allowed fixation deviation
p.allowed_fix_deviation = 3.5 * p.pixels_per_degree;

%-------------------------------------------------------------------------%
%% COLORS
p.bgcolor               = [60 60 60];
p.fgcolor               = [75 0 0];
p.textcolor             = [250 250 250];
p.gray_visible_light    = p.bgcolor+30; 
p.placeholdercolor      = p.fgcolor;
p.cuecolor              = p.bgcolor+30;
p.popoutcolor           = [0 0 200];

p.testcolor             = p.fgcolor;    
p.fix1color             = p.bgcolor-50;
p.fix2color             = p.fgcolor; 
%---------5----------------------------------------------------------------%


%-------------------------------------------------------------------------%
%%% STIMULI
% in matrix arrangement, step and offset from center
p.minoffset             = 5   * p.pixels_per_degree;
p.step                  = 3   * p.pixels_per_degree;

% stimulus eccentricity from center
p.radius                = 6   * p.pixels_per_degree; 

% stimulus rectangle size
p.rectwidth             = 0.2 * p.pixels_per_degree;
p.rectheight            = 1.7 * p.pixels_per_degree;

% fixation dot size
p.fixsize               = 15;% * p.pixels_per_degree; %0.5 * p.pixels_per_degree;

% distance of peripheral fixation dots
p.fix_ecc               = 12  * p.pixels_per_degree;

% cue line, if there is one
p.cuelength             = 2   * p.pixels_per_degree;

% cue dot, if there is one
p.cuesize               = 20;

% size of placeholder dots
p.placeholdersize       = 0.23  * p.pixels_per_degree;


p.symbolsize = 150;

%-------------------------------------------------------------------------%



    p.draw_three_fixations  = 0;

    p.bgcolor               = [100 100 100];
    p.fgcolor               = [200 0 0];
    p.gray_visible_light    = p.bgcolor+30; 
    p.placeholdercolor      = p.bgcolor+30;
    p.cuecolor              = [255 255 255];
    p.popoutcolor           = [0 0 200];

    p.testcolor             = p.fgcolor;    
    p.fix1color             = [0 0 0];
    p.fix2color             = p.fgcolor; 
    
    p.matrix                = 2;
    p.targetnumber          = 12;
    p.cue_as_dot            = 1;
    
    p.radius                = 5   * p.pixels_per_degree; 
    p.circlesize            = 2   * p.pixels_per_degree;

    % distance of peripheral fixation dots
    p.fix_ecc               = 8  * p.pixels_per_degree;
    p.noiseluminance        = 150;
    p.noiseendsize          = 20;
    
    p.noiseluminance        = 180;
    p.noisestartsize        = 1;
    p.noiseendsize          = 20;
    p.framestorun           = 6;
    
    % in matrix arrangement, step and offset from center
    p.minoffset             = 6   * p.pixels_per_degree;
    p.step                  = 8   * p.pixels_per_degree;

    % stimulus eccentricity from center
    p.radius                = 4   * p.pixels_per_degree; 
    
    % stimulus rectangle size
    p.rectwidth             = 0.3 * p.pixels_per_degree;
    p.rectheight            = 2 * p.pixels_per_degree;
    
    % how many frames do we want to display
    p.framestorun           = 6;





%-------------------------------------------------------------------------%
% TEXTS
p.postpracticetext='This was practice.\n\n\nTime for a break.\n\nPress Space when ready.';
p.postblocktext='Time for a break.\n\nPress Space when ready.';
p.postexptext='This was it for today!\n\nThanks (:';

p.featurecuetext='Please report whether the LOCATION of the circle changed.\n\n\nYou will see color cues.';
p.spacecuetext='Please report whether the COLOR of the circle changed.\n\n\nYou will see location cues.';
%-------------------------------------------------------------------------%



%-------------------------------------------------------------------------%
% RANDOMIZATION
p.rnd.seed = sum(clock);
try
    rng('default');
    rng( p.rnd.seed );
catch
    rand('twister', p.rnd.seed );
end
%-------------------------------------------------------------------------%



%-------------------------------------------------------------------------%
% EYETRACKING
% calibration coordinates
xmax = 400;%p.s.eccen + p.s.eccen_rng + max(p.s.xdispl) + 1*p.scr.pixdeg;
ymax = 300;%7 * p.scr.pixdeg;
xcalib  = [ p.scr.width/2 - xmax ...
            p.scr.width/2 ...
            p.scr.width/2 + xmax ];
ycalib  = [ p.scr.height/2 - ymax ...
            p.scr.height/2 ...
            p.scr.height/2 + ymax ];
p.et.calibxy = round( [ xcalib(2) ycalib(2); ...
                        xcalib(2) ycalib(1); ...
                        xcalib(2) ycalib(3); ...
                        xcalib(1) ycalib(2); ...
                        xcalib(3) ycalib(2); ...
                        xcalib(1) ycalib(1); ...
                        xcalib(3) ycalib(1); ...
                        xcalib(3) ycalib(3); ...
                        xcalib(1) ycalib(3) ] );
%-------------------------------------------------------------------------%

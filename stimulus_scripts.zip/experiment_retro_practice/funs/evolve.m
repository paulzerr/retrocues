function [p] = evolve(correct, p)


c=mean(correct);
%level=1;



level=p.level;


if c>.60 && p.level<2
    level=2;
    correct_reached = '60';
end
if c>.65 && p.level<3
    level=3;
    correct_reached = '65';
end
if c>.70 && p.level<4
    level=4;
    correct_reached = '70';
end
if c>.75 && p.level<5
    level=5;
    correct_reached = '75';
end    
if c>.80 && p.level<6
    level=6;
    correct_reached = '80';
end
if c>.85 && p.level<7
    level=7;
    correct_reached = '85';
end
if c>.90 && p.level<8
    level=8;
    correct_reached = '90';
end



if level>p.level % level up

    charimage = imread(['media/evo/' p.charactername num2str(p.level) '.png']);
    chartexture0 = Screen('MakeTexture', p.w, charimage);

    charimage = imread(['media/evo/' p.charactername num2str(level) '.png']);
    chartexture1 = Screen('MakeTexture', p.w, charimage);           

    Screen('FillRect', p.w, [0 0 0])
    Screen('DrawTexture',p.w, chartexture0, [], [], 0);
    Screen('Flip',p.w);
    WaitSecs(2);

    
    for i=1:8
        Screen('FillRect', p.w, [0 0 0])
        Screen('DrawTexture',p.w, chartexture0, [], [], 0);
        Screen('Flip',p.w);
        WaitSecs(.05);

        Screen('FillRect', p.w, [170 170 170])
        Screen('Flip',p.w);
        WaitSecs(.025);

        Screen('FillRect', p.w, [0 0 0])
        Screen('DrawTexture',p.w, chartexture1, [], [], 0);
        Screen('Flip',p.w);
        WaitSecs([.03 * i]);
    end

    
    Screen('FillRect', p.w, [0 0 0])
    Screen('DrawTexture',p.w, chartexture1, [], [], 0);
    Screen('Flip',p.w);
    WaitSecs(1.5);

    Screen('DrawTexture',p.w, chartexture1, [], [], 0);
    DrawFormattedText(p.w, ['You have reached ' correct_reached '% correct ! \n\n\n' p.charactername ' has evolved to level ' num2str(level) ' !!!\n\n\n Press space to continue.'], 'center', 800, p.textcolor);
    Screen('Flip',p.w);

    FlushEvents('keyDown');    
    KbStrokeWait;           

end


p.level = level;
    
    

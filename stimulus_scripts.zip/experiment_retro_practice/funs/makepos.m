function [coords] = makepos(p)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MAKE STIMULUS CENTERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% relate positions to arbitrary center (i.e. fixation)
% x,y = move this dot left/right, up/down
dotxvals=[]; dotyvals=[];
rotation=360/p.targetnumber;

if p.matrix==0 
    for i=1:p.targetnumber
       degs=(360/p.targetnumber)*i+rotation;
       [x,y]=sincos(degs,p.radius); 
       dotxvals=[dotxvals x];
       dotyvals=[dotyvals y];
    end             
    %dotpos = [p.xCenter+dotxvals; p.yCenter+dotyvals];
end



for i=1:p.targetnumber
   minoffset = p.minoffset; 
   if p.matrix==1
   step = p.step;
   switch i
       case 1
           y = -minoffset - step;
           x = -minoffset;
       case 2
           y = -minoffset - step;
           x = minoffset;
       case 3
           y = -minoffset;
           x = -minoffset;             
       case 4
           y = -minoffset;
           x = minoffset; 
       case 5
           y = minoffset;
           x = -minoffset;
       case 6
           y = minoffset;
           x = minoffset;
       case 7
           y = minoffset + step;
           x = -minoffset;             
       case 8
           y = minoffset + step;
           x = minoffset ;
       case 9
           y = -minoffset;
           x = -minoffset - step;
       case 10
           y = minoffset;
           x = -minoffset - step;
       case 11
           y = - minoffset;
           x = minoffset + step;             
       case 12
           y = minoffset;
           x = minoffset + step;   
       case 13
           y = 0;
           x = minoffset;            
       case 14
           y = -minoffset;
           x = 0; 
       case 15
           y = minoffset;
           x = 0;
       case 16
           y = 0;
           x = -minoffset;
       case 17
           y = -minoffset - step;
           x = 0;              
       case 18
           y = 0;
           x = minoffset + step;
       case 19
           y = 0;
           x = -minoffset - step;               
       case 20
           y = minoffset + step;
           x = 0;

   end   


   elseif p.matrix==2
   step = p.minoffset/2;

   switch i
       case 1
           y = -minoffset;
           x = 0;
       case 2
           y = -step;
           x = step;
       case 3
           y = 0;
           x = minoffset;             
       case 4
           y = step;
           x = step; 
       case 5
           y = minoffset;
           x = 0;
       case 6
           y = step;
           x = -step;
       case 7
           y = 0;
           x = -minoffset;             
       case 8
           y = -step;
           x = -step;
       case 9
           y = -minoffset;
           x = -minoffset;
       case 10
           y = minoffset;
           x = minoffset;
       case 11
           y = minoffset;
           x = -minoffset;             
       case 12
           y = -minoffset;
           x = minoffset;   
   end        


   end % matrix selection
   dotxvals=[dotxvals x];
   dotyvals=[dotyvals y];

end 


% relate positions to actual center (i.e. fixation)
dotpos = [p.xCenter+dotxvals; p.yCenter+dotyvals];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

coords.dotpos=dotpos;    
    
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MAKE RECTANGLE TEXTURES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
coords.rect(1:p.targetnumber) = Screen('MakeTexture', p.w, 255);
for ii=1:p.targetnumber
    coords.rectd(:,ii)=CenterRectOnPointd([0 0 p.rectwidth p.rectheight], dotpos(1,ii),dotpos(2,ii));
end


for ii=1:p.targetnumber
    coords.rectc(:,ii)=CenterRectOnPointd([0 0 p.symbolsize p.symbolsize], dotpos(1,ii),dotpos(2,ii));
end





orientation=randsample([0 45 90 135],p.targetnumber,1);
orientationswitch=1:p.targetnumber;
for i=1:p.targetnumber
    switch orientation(i)
       case 0
           orientationswitch(i)=90;
       case 45
           orientationswitch(i)=135;
       case 90
           orientationswitch(i)=0;    
       case 135
           orientationswitch(i)=45;  
    end
end
coords.orientation = orientation;
coords.orientationswitch = orientationswitch;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MAKE CUE LINE COORDINATES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
cuexstart=[]; cueystart=[];
cuexend=[]; cueyend=[];

for i=1:p.targetnumber
   degs=(360/p.targetnumber)*i + rotation;
   [xs,ys]=sincos(degs,0); 
   cuexstart=[cuexstart xs];
   cueystart=[cueystart ys];

   [xe,ye]=sincos(degs,p.cuelength);
   cuexend=[cuexend xe];
   cueyend=[cueyend ye];
end

cueposstart = [p.xCenter + cuexstart; p.yCenter + cueystart];
cueposend = [p.xCenter + cuexend; p.yCenter + cueyend];

cuepos=[];
for i=1:length(cueposstart)
    cuepos=[cuepos cueposstart(:,i)];
    cuepos=[cuepos cueposend(:,i)];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

coords.cuepos = cuepos;


%%% CHOOSE TARGET HERE
coords.position = randsample([1:p.targetnumber],1);

%%% CHOOSE POPOUT HERE
coords.popoutsame = coords.position;


coords.popoutother = randsample([1:p.targetnumber],1);
while coords.popoutother == coords.position
    coords.popoutother = randsample([1:p.targetnumber],1);
end
coords.popdistance=[coords.dotpos(:,coords.position)'; coords.dotpos(:,coords.popoutother)'];


% choose random new target location (color tasks)
coords.newposition = Sample(1:p.targetnumber);
while coords.newposition==coords.position
    coords.newposition = Sample(1:p.targetnumber);
end





end


function [x,y] = sincos(degs,radius)
    y = sin(deg2rad(degs))*radius;
    x = cos(deg2rad(degs))*radius;
end

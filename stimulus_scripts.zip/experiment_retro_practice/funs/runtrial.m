function [abort, gotosetup, invalid, data, flips, coords ] = runtrial(p, t, data, iblock, el)

flips = [];

%start eyelink recording                         
if ~p.dummymode
    [eye_used] = eyelink_startrec(1000,el);else;eye_used=1; 
end

% draw regions of interest on eyelink screen
if ~p.dummymode
    eyelink_drawoct( [p.xCenter p.yCenter], p.allowed_fix_deviation );
    eyelink_drawoct( [p.xCenter p.yCenter], 4 );
end

tex=t.tex(randsample(p.totalnoisetex,p.framestorun));
masktex=t.masktex;

% make trial stimuli     
[coords] = makepos(p);

% default fixation at center
gazepos=[p.xCenter p.yCenter];

% retrieve trial type 
poss=p.poss(p.itrial,:);
sameordiff = poss(1); %1=change, 0=nochange
tt         = poss(2);

saccadeto = 1;

if tt==1 
    showcue = 0; %postcue
elseif tt==2 
    showcue = 1; %retrocue
end    


if p.soundfeedback
    % open sound bits
    Fs = 2000; t = 0:1/2e4:1; s1 = 1/2*cos(2*pi*5000*t);
    Fs = 2000; t = 0:1/2e4:1; s2 = 1/2*cos(2*pi*3000*t);
    pahandle1 = PsychPortAudio('Open', [], [], 0, Fs, 1);
    pahandle2 = PsychPortAudio('Open', [], [], 0, Fs, 1);
    PsychPortAudio('FillBuffer', pahandle1, s1);
    PsychPortAudio('FillBuffer', pahandle2, s2);
end


% sceen names
%                 1         2         3             4            5          6            7           8      9       10       11            
scrNames   = ['pretrial' 'blank1' 'mem_array' 'noisemask1' 'noisemask2' 'blank2_fix' 'blank2_sacc' 'cue' 'blank3' 'probe' 'blank4']; 
% screen durations
scrDur     = [Inf           500       500           -1          -1          250          800       250     1000     Inf      50];

% if this is a post-cue trial show probe instead of cue (skip cue and blank3)
if showcue == 0 
    scrDur(8)  = -1;
    scrDur(9)  = -1;
end

if p.debug==1
    scrDur = [1 1 1 1 1 1 1 1 1 Inf 1];
end

% make ms into frames
scrDur     = round((scrDur./1000)./p.scr.ifi);

% which screens require a response?
iResp      = [10];     
% in which screens should we check gaze fixation?
iFix       = [2,3,8,9,10];   

% initial control variables
currscreen      = 1;
nextscreen      = 1; 
fScreen         = scrDur(1);
firstiteration  = 1;
drawnext        = 1;
abort           = 0;
gotosetup       = 0;
manualresponse  = 0;
invalid         = 0;

% initial output variables
response        = -1;
mrt             = -1;
%flips     = NaN(1,length(scrNames)+p.f.vy-1);





%% Eyelink                          
FlushEvents('keyDown');

% send message to start trial
if ~p.dummymode && ~p.practice
    Eyelink('Message', 'TRIAL %d', p.totaltrials);
    WaitSecs(0.001);
end

%% Run trial
tFlip=0;
while ~abort && ~gotosetup
    	
    %% get gaze coordinates
    if ~p.dummymode
        if Eyelink('NewFloatSampleAvailable') > 0
            evt = Eyelink('NewestFloatSample');
            gx = evt.gx(1 + eye_used);
            gy = evt.gy(1 + eye_used);
        end
    else
        [gx, gy] = GetMouse(p.w);
    end

    % check if gaze is valid  
    if p.check_gaze && ismember(currscreen,iFix)  
        if sqrt( (gx-gazepos(1))^2 + (gy-gazepos(2))^2 ) > p.allowed_fix_deviation
            invalid = 1;

            if ~p.dummymode && ~p.practice
                Eyelink('Message', 'INVALID');
                Eyelink('Message', 'TRIALEND'); 
                Eyelink('Message', 'TRIALEND_OF %d', p.totaltrials);                 
                WaitSecs(0.001);
            end
            Screen('FillRect', p.w, p.bgcolor);
            DrawFormattedText(p.w, 'x', 'center', 'center', [0 0 200]);
            Screen('Flip',p.w);
            KbStrokeWait;
            break % end trial if gaze invalid
        end    
    end 



    %% Draw          
    if drawnext
        drawnext = 0;

        switch nextscreen
            case 1
                % blue fix
                %    targets, cue, probe, fixpos, fixcolor
                drawstimarray(p, 0, 0, 0, 1, 1, sameordiff, coords);

            case 2
                % red fix
                drawstimarray(p, 0, 0, 0, 1, 0, sameordiff, coords);
                
            case 3
                % mem array
                drawstimarray(p, 1, 0, 0, 1, 0, sameordiff, coords);
                
            case 4

            case 5
                % noise masks
                if ~p.debug 
                    for xxx=1:p.framestorun
                        Screen('DrawTextures', p.w, tex(xxx), [], p.wrect , [], 0);
                        Screen('DrawTextures', p.w, masktex, [], p.wrect); 
                        Screen('Flip',p.w);
                        if p.takescreenshot==2
                            WaitSecs(.1);
                            imageArray = Screen('GetImage', p.w);
                            WaitSecs(.01);
                            a=num2str(rand);
                            imwrite(imageArray, [num2str(nextscreen) a '.png']);
                            WaitSecs(.01);
                        end
                    end
                end
                
            case 6
                % blank
                drawstimarray(p, 0, 0, 0, 1,         0, sameordiff, coords);                

            case 7
                % blank
                drawstimarray(p, 0, 0, 0, saccadeto, 0, sameordiff, coords);

            case 8
                % cue
                drawstimarray(p, 0, 1, 0, saccadeto, 0, sameordiff, coords);

            case 9
                % blank
                drawstimarray(p, 0, 0, 0, saccadeto, 0, sameordiff, coords);

            case 10
                % response
                % this includes a cue if post-cue condition
                drawstimarray(p, 0, 1, 1, saccadeto, 0, sameordiff, coords);

            case 11
                % response
                drawstimarray(p, 0, 0, 0, saccadeto, 0, sameordiff, coords);
        end
        
        
    end
     
    %% Visual                    	
    % how may flips have passed since last flip?
    fSinceFlip = (GetSecs()-tFlip)/p.scr.ifi;

    
    % update the screen
    if firstiteration  ||  fSinceFlip > fScreen-0.5 || manualresponse

        
        % FLIP, unless we want to skip this screen
        if scrDur(nextscreen) ~= 0
            tFlip = Screen('Flip',p.w);
        end
        
        % set current screen as the one we just flipped
        currscreen = nextscreen;

        % this screen should last this long:
        fScreen = scrDur( currscreen );

        % send screen number to eyelink
        if ~p.dummymode && ~p.practice
            Eyelink( 'Message', ['screen_' num2str(nextscreen)] );
        end

        % advance screen counter
        nextscreen=currscreen+1;

        %set mrt reference
        if ismember(currscreen, iResp)
            mrtref = tFlip;
        end
        
        % make sure next screen will be drawn
        drawnext = 1;
        % if we flipped this is not the first iteration of the loop
        firstiteration = 0;
        % reset keypress boolean
        manualresponse = 0;
        FlushEvents('keyDown');
    end %end flip section
    
                       
    % check for key press
    [keyIsDown, secs, keyName] = KbCheck_JF;
    if keyIsDown
        
        % change variables appropriately
        if ismember(keyName,{'BackSpace','q'})
            abort = true;
            
        elseif strcmp(keyName,'ESCAPE')
            gotosetup = 1;
            invalid = 1;
            break
            
        elseif strcmp(keyName,'UpArrow') && ismember(currscreen,iResp)
            if ~p.dummymode && ~p.practice
                Eyelink('Message', 'RESPONDED_CHANGE');
                WaitSecs(0.001);
            end
            response = 1;
            mrt      = secs - mrtref;
            manualresponse=1;
            
        elseif strcmp(keyName,'DownArrow') && ismember(currscreen,iResp)
            if ~p.dummymode && ~p.practice
                Eyelink('Message', 'RESPONDED_NOCHANGE');
                WaitSecs(0.001);
            end
            response = 0;
            mrt      = secs - mrtref;
            manualresponse=1;
            
        elseif strcmp(keyName,'space')  && ismember(currscreen,1)
            manualresponse=1;
        end
    end
    
    if currscreen==length(scrDur)
        break %end trial if this was the last screen
    end

end

% record trial results
if ~abort 
    data{end+1} = {response, sameordiff, showcue, tt, mrt, coords, p, invalid, p.itrial, iblock, saccadeto};
end

% sound feedback
if p.soundfeedback && ~invalid && ~abort
    % if incorrect
    if sameordiff~=response 
        PsychPortAudio('Start', pahandle1, 1, 0, 1, 0.25);
        PsychPortAudio('Stop', pahandle1);
    % if correct
    else 
        PsychPortAudio('Start', pahandle2, 1, 0, 1, 0.25);
        PsychPortAudio('Stop', pahandle2);
    end

    WaitSecs(0.01);
    PsychPortAudio('Close', pahandle1);
    PsychPortAudio('Close', pahandle2);
end

% close rectangle coordinates
Screen('Close', coords.rect)
% Screen('Close', tex)
% Screen('Close', masktex)


% Final messages
WaitSecs(0.001);
if ~p.dummymode 
    % clear experiment screen
    Eyelink('Command','clear_screen 0' );
    Eyelink('Message', 'TRIALEND');
    WaitSecs(0.01);
    Eyelink('StopRecording');
    WaitSecs(0.01);
end
WaitSecs(0.001);



end



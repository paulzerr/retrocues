function [] = drawfeedback(p,correct,tt)


    stepx=40;
    stepy=40;

    if p.totaltrials > 30
        stepx=25;
        stepy=25;    
    end
    if p.totaltrials > 50
        stepx=15;
        stepy=15;
    end
    if p.totaltrials > 100
        stepx=8;
        stepy=8;
    end
    if p.totaltrials > 200
        stepx=4;
        stepy=4;
    end
    if p.totaltrials > 450
        stepx=2;
        stepy=2;
    end

    backgroundcolor=0;
    drawmode=2;

    % fill background
    Screen('FillRect', p.w, backgroundcolor)

    % draw accuracy grid
    drawacc(p,stepx,stepy)

    % draw actual lines
    [x,y]=drawprog(p,correct,255,p.wrect(4)-106,stepx,stepy,drawmode);

    

    theImageLocation = ['media/evo/Bird' num2str(p.level) '.png'];

    [theImage,map,alpha] = imread(theImageLocation);
    theImage(:,:,4) = alpha;
    %stimuli(images)=Screen('MakeTexture', p.w, I);
    %p.stimuli=stimuli;
    
    imageTexture = Screen('MakeTexture', p.w, theImage);
    avatar_height=size(theImage,1);
    avatar_width=size(theImage,2);

    rect=[0 0 avatar_width/2 avatar_height/2];

    rect = CenterRectOnPoint(rect,x+200,y);
    Screen('DrawTexture',p.w, imageTexture, [], rect, 0);

    
    % y axis
    %Screen('DrawLines', p.w, [100 100 ; p.wrect(4) 0], 3, [255 255 255], [0 0], 2);

    % display
    Screen('Flip',p.w);
    
    %WaitSecs(.01);
    %imageArray = Screen('GetImage', w);
    %imwrite(imageArray, ['ppt' num2str(i) '.jpg'])

    KbPressWait;
    KbReleaseWait;
end

%% draws feedback lines based on data input
function [x,y] = drawprog(p,a,cols,y,stepx,stepy,drawmode)

    s    = []; 
    x    = 100;

    adjusttrialsep=0;
    
    if drawmode==1
        for i=1:length(a)
            s(:,end+1) = [x y];    % start - vertical
            if a(i)==1
                y=y-stepy;
            else
                y=y+stepy;
            end
            s(:,end+1) = [x y];   % end - vertical

            s(:,end+1)=[x y];     % start - horizontal
            x=x+stepx;
            s(:,end+1)=[x y];     % end - horizontal
        end

    elseif drawmode>1
        for i=1:length(a)
            s(:,end+1) = [x+adjusttrialsep y];    % start - vertical
            if a(i)==1
                y=y-stepy;
            else
                y=y+stepy;
            end
            x=x+stepx+adjusttrialsep;
            s(:,end+1) = [x y];   % end - vertical
        end
    end

    Screen('DrawLines', p.w, s, 5, cols, [0 0], 2);

    if drawmode==1
        %Screen('DrawLines', p.w, s(:,end-(4*p.feedbackeveryxtrials)+1:end), 5, [0 0 255], [0 0], 2);
    elseif drawmode==2
        %Screen('DrawLines', p.w, s(:,end-(2*p.feedbackeveryxtrials)+1:end), 5, [0 0 255], [0 0], 2);
        Screen('DrawLines', p.w, s(:,end-(2*p.feedbackeveryxtrials)+1:end), 5, [255 255 255], [0 0], 2);
    elseif drawmode==3
        'none'
    end
end


function drawacc(p,stepx,stepy)

    for attrial=1:700
        for i=1:10
            percentagecorrect = 105-(i*5);
            height = (attrial - 2*(attrial-(percentagecorrect*0.01*attrial))) * stepy;

            if mod(percentagecorrect,10)
                dotcolor=200;
            else
                dotcolor=150;
            end
            Screen('DrawDots', p.w, [100+(stepx*attrial)  p.wrect(4)-100-height], 5, dotcolor);  
            if attrial==100
                Screen('TextFont', p.w,'Helvetica');
                Screen('TextSize', p.w, 15);
                Screen('DrawText', p.w, [num2str(percentagecorrect) '%'], 105+(stepx*attrial),  p.wrect(4)-120-height  , dotcolor, []);    
            end
        end % end ten accuracy lines
    end % end for each trial
end % end dracacc function



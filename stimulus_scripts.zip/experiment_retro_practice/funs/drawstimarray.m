function drawstimarray(p, showtargets, showcue, showprobe, fixpos, fixcolor, sameordiff, coords)

Screen('FillRect', p.w, p.bgcolor)
Screen('DrawDots', p.w, coords.dotpos, p.placeholdersize, p.placeholdercolor, [], 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DRAW STIMULUS CIRCLES + RECTANGLES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if showtargets==1
    
    Screen('DrawTextures', p.w, coords.rect, [], coords.rectd, coords.orientation, 0,[], p.fgcolor);

    if p.debug==2
        for i=1:p.targetnumber
            Screen('DrawText', p.w, num2str(i), coords.dotpos(1,i), coords.dotpos(2,i), [255 255 255]);        
        end
    end
  
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SHOW PROBE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if showprobe==1

    if sameordiff==1 % if change trial, switch position/color
        coords.orientation(coords.position)=coords.orientationswitch(coords.position);  
    else    
        newposition = coords.position;
    end

    Screen('DrawTextures', p.w, coords.rect, [], coords.rectd, coords.orientation, 0, [], p.testcolor);
   
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SHOW CUE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if showcue>0
    
	Screen('DrawDots', p.w, coords.dotpos(:,coords.position), p.cuesize, p.cuecolor, [], 2);

end    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SHOW FIXATION DOTS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if fixcolor==1
    drawfixationas=p.fix1color;
elseif fixcolor==0;
    drawfixationas=p.fix2color;
end

colpos=repmat(p.gray_visible_light,3,1);
colpos(fixpos,:)=drawfixationas;

if showcue==0 || showprobe
    drawfixation(2, p.w, [p.xCenter p.yCenter], p.fixsize, [colpos(1,:); p.bgcolor]', p.fixsize*0.3); 
end






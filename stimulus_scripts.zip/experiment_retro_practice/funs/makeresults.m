function [correct,tt, pos] = makeresults(filename)
%filename
char(cellstr(filename));
load(char(cellstr(filename)));

correct = [];
tt      = [];
pos     = [];

%{response, sameordiff, showcue, saccadeto, mrt, coords.position, p.targetnumber, invalid, itrial, iblock};
for i=1:length(data)
    a = data{i};
    if cell2mat(a(8))==0 % if trial is valid
        correct = [correct cell2mat(a(1))==cell2mat(a(2))];
        tt      = [tt cell2mat(a(4))];
        
        p=cell2mat(a(7));
        
        try
            pos     = [pos p.spacecue];
        catch
            pos     = [pos 0];
        end
        
    end
end

function [t] = makenoise(p)

% find background gray 
bgcolor=p.bgcolor(1);

% find screen size
[p.screenXpixels, p.screenYpixels] = Screen('windowSize', p.w);


%% MAKE NOISE PATCHES
% create filter operator
out = fspecial('gaussian',p.kwidth,p.kwidth/2);
convoperator = CreateGLOperator(p.w, kPsychNeed32BPCFloat);
Add2DConvolutionToGLOperator(convoperator, out, [], 3, 3);

% make filter
texsize=50;
gray=bgcolor;
white=255;
angle=p.noiseangle;
mask=ones(2*texsize+1, 2*texsize+1, 2) * gray;
[x,y]=meshgrid(-1*texsize:1*texsize,-1*texsize:1*texsize);
mask(:, :, 2)=white * (1 - exp(-((x/angle).^2)-((y/angle).^2)));
masktex=Screen('MakeTexture', p.w, mask);

% make noise size vectors
dimension1=[];
dimension2=[];

while length(dimension1)<p.totalnoisetex%p.framestorun
    for i=p.noisestartsize:p.noiseendsize
        dimension1=[dimension1 round(p.screenYpixels/i)];
        dimension2=[dimension2 round(p.screenXpixels/i)];       
    end
end

a=0;
b=p.noiseluminance;
for i=1:p.totalnoisetex%p.framestorun
    % make noise matrix
    noiseimg = a + (b-a).*rand(dimension1(i),dimension2(i),3);
    % make noise texture
    tex(i)=Screen('MakeTexture', p.w, noiseimg);
end


t.tex=tex;
t.masktex=masktex;



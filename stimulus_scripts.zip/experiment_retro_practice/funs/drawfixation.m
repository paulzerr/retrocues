function drawfixation( type, w, xy, diam, colors, lw  )                 
%DRAWFIXATION Draw the best fixation target there is
%   According to Thaler et al. (2013) the best fixational stability is
%   achieved using a combination of a bulls-eye and a cross as a fixation
%   target. Drawfixation uses PTB 'DrawDots' and 'DrawLine'
%
%   Input
%   - type      1 = single dot
%               2 = dot with small dot inside
%               3 = best fixation of Thaler et al. (2013)
%   - w         PTB windowpointer
%   - xy        two row vector containing x and y of fixation target [x;y]
%   - diam      diameter of bulls-eye target (pixels)
%   - colors    1*2 | 3*2 matrix, specifying RGB color for target (first 
%               column) and background (second column) 
%   - lw        if type == 2: diameter of inner dot (pixels)
%               if type == 3: linewidth of cross (pixels)
%   
%   Note on 'diam' and 'lw', fixation point is symmetric when both these
%   arguments are even integers
%
%                                                  Created by JHF (07-2016)

switch type
    case 1
        Screen('DrawDots', w, xy, diam, colors(:,1), [], 1);
    case 2
        Screen('DrawDots', w, xy, diam, colors(:,1), [], 1);
        Screen('DrawDots', w, xy, lw,   colors(:,2), [], 1);
    case 3
        Screen('DrawDots', w, xy, diam, colors(:,1), [], 1);
        Screen('DrawLine', w, colors(:,2), xy(1)-diam, xy(2),      xy(1)+diam, xy(2),      lw)
        Screen('DrawLine', w, colors(:,2), xy(1),      xy(2)-diam, xy(1),      xy(2)+diam, lw)
        Screen('DrawDots', w, xy, lw*1.5, colors(:,1), [], 1);
end

end
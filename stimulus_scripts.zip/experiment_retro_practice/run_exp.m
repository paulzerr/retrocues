%-------------------------------------------------------------------------%
% Stimulus Script 
% "The development of retro-cue benefits with extensive practice"
% osf.io/9xr82
%
% contact: zerr.paul@gmail.com
%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
% CLEAN WORKSPACE AND INITIALIZE
close all; clear all; clc; commandwindow;


%PsychDebugWindowConfiguration


% load parameters
[p]     = SETTINGS('lab');
data    = {};


% set directories 
addpath([pwd filesep 'funs']);
addpath([pwd filesep 'data']);
addpath([pwd filesep 'toolbox']);
addpath([pwd filesep 'media']);
matdir = [pwd filesep 'data' filesep 'mat' filesep];
edfdir = [pwd filesep 'data' filesep 'edf' filesep];
datdir = [pwd filesep 'data' filesep 'other' filesep];


if p.getsubjinfo
    % get subject/session info
    subj.initials = inputgui('Your initials:');
    subj.sessnr   = inputgui('Session number:');
    if ~p.choosecharacter
        p.level   = inputgui('Previous level:');
        p.character   = inputgui('Character:');
    end

    % create mat file unless filename exists
    if isempty( ls( [ matdir filesep '*' subj.initials subj.sessnr '*'] ) )
        filename=['exp_res_' subj.initials num2str(subj.sessnr)];
        save([matdir filename],'data')
    else
        error(['Error: file exists: ' upper(subj.initials) subj.sessnr ]);
    end
else
    filename = 'testing';
end
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
% INITIALIZE SCREEN
AssertOpenGL; % pretty graphics
commandwindow; % key press will not write in script

if p.synctest
    Screen('Preference', 'SkipSyncTests', 0); % tight control on timing
    Screen('Preference', 'VisualDebuglevel', 0);
else
    Screen('Preference', 'SkipSyncTests', 2); % time-insensitive testing
    Screen('Preference', 'VisualDebuglevel', 3);
end

[p.w, p.wrect] = Screen('OpenWindow', p.scrnum, [0 0 0]); % open the window

Priority(MaxPriority(p.w)); % you have one job, pc
HideCursor(p.w,0); % get rid of that mouse
KbName('UnifyKeyNames'); % make keyboard presses mean the same on any pc

Screen('BlendFunction', p.w, GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); % make it smooth
Screen('TextFont', p.w,'Helvetica');
Screen('TextSize', p.w, 23);
Screen('Preference', 'TextRenderer', 0);

% premake noise patches
[t]=makenoise(p); 

% init sound
if p.soundfeedback
    InitializePsychSound;
end
%-------------------------------------------------------------------------%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  VISUAL STARTS HERE    %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-------------------------------------------------------------------------%
%% INSERT COIN_

Screen('FillRect', p.w, 0);
DrawFormattedText(p.w, 'Welcome. \n\nPress any key to start.', 'center', 'center', p.textcolor);
Screen('Flip',p.w);
KbStrokeWait;



%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%% EYELINK STUFF
% open eyetracker
if ~p.dummymode
    el = EyelinkInitDefaults(p.w);
    eyelink_init(el, p.wrect, p.bgcolor, p.fgcolor, false, p.et.calibxy);
    WaitSecs(.01);
    FlushEvents('keyDown');
    EyelinkDoTrackerSetup(el); %eyetracker setup
    KbReleaseWait;
else
    el=[];
end

%open eyelink file
if ~p.dummymode
    edfname = [filename '.edf'];
end   

if ~p.dummymode && Eyelink('Openfile',edfname) ~= 0
    error('Failed to create EDF file: ''%s'' ', edfname);
end   
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
% MAKE GRAY BACKGROUND ISOLUMINANT TO RED FOREGROUND
if p.isolum
    max_red             = p.fgcolor(1);
    p.bgcolor           = isoluminator(p, max_red, [1 1 1], [1 0 0], 1, 120);
    isolumvals          = p.bgcolor;
    save([datdir filename 'iso'],'isolumvals')
end
%-------------------------------------------------------------------------%



%-------------------------------------------------------------------------%
%  INSTRUCTIONS
if p.showinstructions==1
    for ins=1:7
        insimage = imread(['media/instructions/' num2str(ins) '.png']);
        instexture = Screen('MakeTexture', p.w, insimage);
        Screen('DrawTexture',p.w, instexture, [], [], 0);
        Screen('Flip',p.w);
        KbStrokeWait;
    end
end


%-------------------------------------------------------------------------%
%% PRACTICE

if p.dopracticeround==1
    if ~p.dummymode 
        Eyelink('Message', 'PRACTICE');
        WaitSecs(0.001);
    end
    p.practice=1;
    abort=0; 
    
    %%% INSTRUCTIONS                                           
    Screen('FillRect', p.w, p.bgcolor);
    DrawFormattedText(p.w, 'Practice', 'center', 'center', p.textcolor);
    Screen('Flip',p.w);
    FlushEvents('keyDown');
    KbStrokeWait;

    % set conditions for practice session
    p.targetnumber = 8;
    p.matrix       = 0;
    p.poss=[0 1; 1 1; 0 1; 1 1; 0 1; 1 1; 1 1; 0 1; 0 1; 1 1; ...
            1 2; 0 2; 1 2; 0 2; 0 2; 1 2; 0 2; 1 2; 0 2; 0 2; 1 2; 0 2; 1 2; 0 2; 0 2; 1 2; 0 2; 1 2; 0 2; 0 2];


    % Run block 
    p.itrial=1;                                     
    while p.itrial <= length(p.poss)

        % run trial                                            
        [abort, gotosetup, invalid, data, flips, coords] = runtrial(p, t, data, 1, el);
        
        if ~invalid 
            p.itrial=p.itrial+1;  % unless invalid trial, move trial counter  
        else
            missed=p.poss(p.itrial,:); % if invalid put current trial to end of block
            p.poss(p.itrial,:)=[];
            p.poss=[p.poss; missed];
        end

        % check if any unusual action is required
        if abort
            break;
        elseif ~p.dummymode && gotosetup
            FlushEvents('keyDown');
            EyelinkDoTrackerSetup(el);
            KbReleaseWait;
        end

    end % end of while
    Screen('FillRect', p.w, p.bgcolor);
    DrawFormattedText(p.w, p.postpracticetext, 'center', 'center', p.textcolor);
    Screen('Flip',p.w);
    KbStrokeWait;
end % if do practice
%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% MAIN EXPERIMENT         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

abort=0;
p.totaltrials=1;
p.practice=0;
p.targetnumber = 12;
p.matrix       = 2;

if ~p.dummymode 
    Eyelink('Message', 'MAIN_EXPERIMENT');
    WaitSecs(0.001);
end

for iblock=1:p.blocks    

    p.trial_types = [1 2 1 2];

    poss = repmat(CombVec([1 0],[p.trial_types])',p.cycles,1);
    p.poss            = poss(randperm(length(poss)),:);  
    
    % clear screen
    Screen('FillRect', p.w, p.bgcolor);
    Screen('Flip', p.w); 
    
    %% Run block 
    p.itrial=1;                                     
    while p.itrial <= length(p.poss)

        % run trial                                            
        [abort, gotosetup, invalid, data, flips, coords] = runtrial(p, t, data, iblock, el);
        
        if p.fliptester
            allflips(p.itrial,:)=flips;
        end
        
        % check if any unusual action is required
        if abort
            break;
        elseif ~p.dummymode && gotosetup
            FlushEvents('keyDown');
            EyelinkDoTrackerSetup(el);
            KbReleaseWait;
        end

        % save after every trial
        save([matdir filename],'data')


     	%----------------------------------------------------------------%
        %%% FEEDBACK VIS       
        if ~mod(p.totaltrials,p.feedbackeveryxtrials) && ~invalid
            Screen('FillRect', p.w, p.bgcolor);
            DrawFormattedText(p.w, 'Let`s see how you did so far...', 'center', 'center', p.textcolor);
            Screen('Flip',p.w);
            WaitSecs(.75);
            
            [correct,tt, pos] = makeresults([matdir filename '.mat']);
            
            if length(correct)>p.min_trials_to_evolve
                p = evolve(correct,p);
            end

            drawfeedback(p,correct,tt);
        end
        %----------------------------------------------------------------%
        
        
        %----------------------------------------------------------------%
        if ~invalid 
            p.itrial=p.itrial+1;  % unless invalid trial, move trial counter  
            p.totaltrials=p.totaltrials+1;
        else
            missed=poss(p.itrial,:); % if invalid put current trial to end of block
            poss(p.itrial,:)=[];
            poss=[poss; missed];
        end     
        %----------------------------------------------------------------%
        
        
        %----------------------------------------------------------------%
        % BREAK AND RECALIBRATION
        % give break after x trials                                            
        if mod(p.totaltrials,p.breakafterxtrials)==0 && ~abort

            % show break text
            Screen('FillRect', p.w, p.bgcolor);
            DrawFormattedText(p.w, p.postblocktext, 'center', 'center', p.textcolor);
            Screen('Flip',p.w);
            % wait for keypress
            FlushEvents('keyDown');
            KbStrokeWait;

            %eyetracker setup
            if ~p.dummymode
                FlushEvents('keyDown');
                EyelinkDoTrackerSetup(el);
                KbReleaseWait;
            end
            
            
        end % end of wrap up block

    end

    if abort
        break;
    end

end % end of blocks

%------------------------------------------------------------------------%
% END EXPERIMENT
if ~abort
    Screen('FillRect', p.w, p.bgcolor);
    DrawFormattedText(p.w, p.postexptext, 'center', 'center', p.textcolor);
    Screen('Flip',p.w);
    FlushEvents('keyDown');
end

if ~p.dummymode
    %save .edf
    if ~p.dummymode 
        saveEDF(edfname,edfdir);
    end
    Eyelink('command', 'generate_default_targets = YES');
end
ShowCursor(p.w);
Priority(0);
sca;
%------------------------------------------------------------------------%



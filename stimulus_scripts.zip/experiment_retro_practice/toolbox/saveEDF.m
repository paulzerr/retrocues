function saveEDF(edfname,edfdir)
% SAVEEDF Receives edf from Eyelink pc.
%
% Input
%   edfname: what is the name of your edf file?
%   edfdir:  (optional) where do you want to store the file? Provide full
%            path to the folder
%-------------------------------------------------------------------------%

Eyelink('Command', 'set_idle_mode');
WaitSecs(0.5);

Eyelink('CloseFile');
WaitSecs(0.5);

status = Eyelink('ReceiveFile',edfname);
if status > 0
    fprintf('ReceiveFile status %d\n', status);
end

if nargin > 1  &&  exist('edfdir','var')  &&  ~isempty(edfdir)
    movefile([pwd filesep edfname],edfdir)
end
function eyelink_drawoct( xy, radius )                                  
%EYELINK_DRAWOCT Draw octagon on eyelink monitor, to approach circular ROI
%little bit nicer than square

% octagon xy
octax = [ 1, sqrt(2)/2, 0, -sqrt(2)/2, -1, -sqrt(2)/2,  0,  sqrt(2)/2 ];
octay = [ 0, sqrt(2)/2, 1,  sqrt(2)/2,  0, -sqrt(2)/2, -1, -sqrt(2)/2 ];

% xy coordinates of octagon
x = round( xy(1) + radius * octax );
y = round( xy(2) + radius * octay );

% draw lines
idx = [1:8 1];
for ii = 1:8
    Eyelink( 'Command','draw_line %d %d %d %d 15', x( idx(ii) ), y( idx(ii) ), x( idx(ii+1) ), y( idx(ii+1) ) );
end

end
function [isocolor] = isoluminator(p, testluminance, matchcanon, fixedcanons, darkest, brightest)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ntrials = p.isoluminance_trials;    % AANTAL TRIALS 

vhDim = 50; % vh dim van vierkant waar kleuren verschijnen; klein houden
backgr = 0;

flickFreq		= 30; % in Hz; Kijk maar bij welke frequency (20-30) je het duidelijkst een elkel punt krijgt waar er geen (of minimaal) flickering te zien is.
screenrefresh = p.scr.hz; % in Hz; niet vergeten in te vullen

dichopres = 1; % voor dichoptische of monoculaire presentatie
intdist=p.pixels_per_degree*10; % afstand tussen plaatjes voor elk oog 

screenPar.SN = max(Screen('Screens'));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% flicker program
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%testluminance   = 255;
%matchcanon 		= [1 1 1]; % welke van de drie kleuren (RGB) moeten gematched worden? (bijv [1 0 0] voor rood, of [1 0 1] voor paars)
%fixedcanons     = [1 0 0]; % welke kleuren staan vast, en worden gebruikt als referentie (altijd de minst luminante van de twee gebruiken). Blauw < Rood < Groen
fixedvalues     = [0 0 0]; 
goalRGB 		= fixedcanons*testluminance; % aan welke rgb-waarde moet gematched worden?

test_max = fixedvalues;
test_min = fixedvalues;
test_max(find(matchcanon)) = brightest;
test_min(find(matchcanon)) = darkest;


history = equilumFunc(p.w, p.wrect, goalRGB,matchcanon,test_max,test_min,vhDim,ntrials,screenPar,flickFreq,dichopres,intdist,screenrefresh,backgr);

for i = 1:ntrials
    matchval(i,:) = history(i).data(end,:);
    nframes(i,:) = length(history(i).data);
end


endmean = mean(matchval,1);
isocolor = round(endmean);


disp(isocolor); %sca; 
return
WaitSecs(.1);
end



function [el] = eyelink_init(el, wRect, colbg, colstim, withsound,  calibxy)
% Input
%   - el
%   - wRect         vector with resolution of stimulus monitor, as obtained 
%                   with Screen('Rect', ...), i.e. [0 0 2560 1440]
%   - colbg         color of calibration background, integer [0:255]
%   - colstim       color of calibration stimuli, integer [0:255]
%   - withsound     play beeps, logical [0 1]
%   - calibxy       two column matrix with xy coordinates of calibration 
%                   targets. Make sure that the order of the coordinates is 
%                   correct*
%                   calibxy must contain 3, 5, 9 or 13 rows, conform the
%                   eyelink calibration routines. If this is not the case,
%                   calibration coordinates will default to standard 9
%                   point calibration
%
%                   * HV5: [x2 y2; x2 y1; x2 y3; x1 y2; x3 y2] 
%                     HV9: [x2 y2; x2 y1; x2 y3; x1 y2; x3 y2; x1 y1; x3 y1; x3 y3; x1 y3] 

%% Set basic Eyelink parameters
% Define visual
el.allowlocalcontrol       = 1;
el.backgroundcolour        = colbg;
el.msgfontcolour           = colstim;
el.imgtitlecolour          = colstim;
el.calibrationtargetcolour = colstim;
el.calibrationtargetsize   = 0.8; % inner size
el.calibrationtargetwidth  = 0.25; % outer size

% Define auditory (frequency, volume, duration);
el.targetbeep = 0;
if withsound
    el.cal_target_beep               =[1250 0.6 0.05];
    el.drift_correction_target_beep  =[1250 0.8 0.05];
    el.calibration_failed_beep       =[400  0.8 0.25];
    el.calibration_success_beep      =[800  0.8 0.25];
    el.drift_correction_failed_beep  =[400  0.8 0.25];
    el.drift_correction_success_beep =[800  0.8 0.25];
else
    el.cal_target_beep               =[1250 0 0.05];
    el.drift_correction_target_beep  =[1250 0 0.05];
    el.calibration_failed_beep       =[400  0 0.25];
    el.calibration_success_beep      =[800  0 0.25];
    el.drift_correction_failed_beep  =[400  0 0.25];
    el.drift_correction_success_beep =[800  0 0.25];
end

EyelinkUpdateDefaults(el);




%% Initialization connection with Eyelink
if Eyelink('Initialize', 'PsychEyelinkDispatchCallback') ~=0
    error('Eyelink initialization failed...')
end



%% Set standard settings
Eyelink('Command', 'binocular_enabled = NO');
Eyelink('Command', 'active_eye = LEFT');
Eyelink('Command', 'pupil_size_diameter = DIAMETER');
Eyelink('Command', 'corneal_mode = YES');
Eyelink('Command', 'sample_rate = 1000'); 
Eyelink('Command', 'use_ellipse_fitter = NO');
Eyelink('Command', 'initial_thresholds = 66, 66, 40, 210, 210')



%% Set calibration ccoordinates
% map gaze position from tracker to screen pixel positions
width  = wRect(3);
height = wRect(4);
Eyelink('command','screen_pixel_coords = %ld %ld %ld %ld', 0, 0, width-1, height-1);
Eyelink('message', 'DISPLAY_COORDS %ld %ld %ld %ld', 0, 0, width-1,height-1);

% set calibration type
if exist('calibxy','var') && ~isempty(calibxy) && ismember( size(calibxy,1), [3 5 9 13] )
    
    % set number of calibration targets
    ncalxy = size(calibxy,1);
    eval( [ 'Eyelink(''command'', ''calibration_type = HV' num2str(ncalxy) ''');' ] );
    
    % you must send this command with value NO for custom calibration
    % you must also reset it to YES for subsequent experiments
    Eyelink('command', 'generate_default_targets = NO');
    
    % modify calibration and validation target locations
    eval( [ 'Eyelink(''command'',''calibration_samples = ' num2str(ncalxy+1) ''');' ] );
    eval( [ 'Eyelink(''command'',''validation_samples = ' num2str(ncalxy) ''');' ] );

    tmpstr_cal = '0';
    tmpstr_val = '0';
    for itmp = 1:ncalxy
        tmpstr_cal = sprintf( '%s, %s', tmpstr_cal, num2str(itmp) );
        tmpstr_val = sprintf( '%s, %s', tmpstr_val, num2str(itmp) );
    end
    
    Eyelink('command', [ 'calibration_sequence = ' tmpstr_cal ] );
    Eyelink('command', [ 'validation_sequence = ' tmpstr_val ] );
    
    % set calibration target coordinates
    xyvect = reshape(calibxy', 1, numel(calibxy));
    
    tmpstr_cal = [ 'Eyelink(''command'',''calibration_targets = ' repmat('%d,%d ',1,ncalxy) ''''];
    tmpstr_val = [ 'Eyelink(''command'',''validation_targets = ' repmat('%d,%d ',1,ncalxy) ''''];
    for itmp = 1:length(xyvect)
        tmpstr_cal = sprintf('%s, %s', tmpstr_cal, num2str(xyvect(itmp)));
        tmpstr_val = sprintf('%s, %s', tmpstr_val, num2str(xyvect(itmp)));
    end
    tmpstr_cal = [ tmpstr_cal ');' ];
    tmpstr_val = [ tmpstr_val ');' ];
    
    eval(tmpstr_cal);
    eval(tmpstr_val);

else
    
    % set default calibration type
    Eyelink('Command', 'calibration_type = HV9');
    Eyelink('Command', 'generate_default_targets = YES');
    
end


% general calibration settings
Eyelink('Command', 'enable_automatic_calibration = YES');	% YES default
Eyelink('Command', 'automatic_calibration_pacing = 1000');	% 1000 ms default
Eyelink('Command', 'randomize_calibration_order = YES');    % YES default
Eyelink('Command', 'randomize_validation_order = YES');     % YES default
Eyelink('Command', 'cal_repeat_first_target = YES');
Eyelink('Command', 'val_repeat_first_target = YES');




%% Set recording configuration
% 1. set parser (conservative saccade thresholds)
Eyelink('Command', 'saccade_velocity_threshold = 35');
Eyelink('Command', 'saccade_acceleration_threshold = 9500');

% 2. set EDF file contents
Eyelink('Command', 'file_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,MESSAGE');

% 3. set link data
Eyelink('Command', 'link_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,MESSAGE,BUTTON,FIXUPDATE,INPUT');
Eyelink('Command', 'link_sample_data  = LEFT,RIGHT,GAZE,GAZERES,AREA,STATUS,INPUT');



end
function [eye_used] = eyelink_startrec(hz,el)
%% STARTEYELINKREC Start eyelink recording with PTB

% check input
if ~exist('hz') || isempty(hz)
    hz = 1000;
end

% convert hz to string
if ~ischar(hz)
    hz_str = num2str(hz);
end

% make sure recording frequency is 1000 Hz
Eyelink('Command', ['sample_rate = ' hz_str]);
WaitSecs(0.1);

% start recording
status = Eyelink('StartRecording');
while status~=0
    status = Eyelink('StartRecording');
    WaitSecs(0.1);
end
WaitSecs(0.1);

% check if recording correctly
errorRecording = Eyelink('CheckRecording');
if(errorRecording~=0)
    warning( 'CheckRecording error, status: %d', errorRecording );
    gotoQuit = true;
end

% get eye that's tracked
eye_used = Eyelink('EyeAvailable');
if eye_used == el.BINOCULAR; % if both eyes are tracked
    eye_used = el.LEFT_EYE;  % use left eye
end

end
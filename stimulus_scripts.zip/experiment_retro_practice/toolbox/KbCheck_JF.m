function [keyIsDown, secs, keyName] = KbCheck_JF                        
% Small modification of KbCheck. 
% Returns name of keycode, and only firstname in case of multiple

[keyIsDown, secs, keyCode] = KbCheck;

% if multiple keynames use first one
allKeyNames = KbName(keyCode);
if iscell(allKeyNames)
    keyName = allKeyNames{1};
else
    keyName = allKeyNames;
end

end